package com.digitalnurture.mockito.basic;

public class MyService {

    private final ExternalApi externalApi;

    public MyService(ExternalApi externalApi) {
        this.externalApi = externalApi;
    }

    public String fetchData() {
        return externalApi.getData();
    }

    public void persist(String data) {
        externalApi.saveData(data);
    }
}
